<?php 
session_start();

unset($_SESSION['banco']);
header("Location: /tcc/index.php");
exit();


?>